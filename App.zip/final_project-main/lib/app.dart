import 'dart:async';

import 'package:final_project/bloc/bloc/gpt_bloc.dart';
import 'package:final_project/cubit/loading_text/loading_text_cubit.dart';
import 'package:final_project/screens/auth/login_screen.dart';
import 'package:final_project/screens/calender_screen.dart';
import 'package:final_project/screens/navigation_bar_screen.dart';
import 'package:final_project/services/database/user_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class App extends StatefulWidget {
  const App({
    super.key,
  });

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  bool canGoHome = false;
  StreamSubscription? listen;

  @override
  void initState() {
    SupabaseData.client.auth.onAuthStateChange.listen((data) {
      final AuthChangeEvent event = data.event;
      if (event == AuthChangeEvent.signedIn) {
        canGoHome = true;
        setState(() {});
      }

      if (event == AuthChangeEvent.signedOut) {
        canGoHome = false;
        setState(() {});
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => LoadingTextCubit(),
        ),
        BlocProvider(
          create: (context) => GptBloc(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Center(
            child: canGoHome ? const NavigationBarScreen() : LoginScreen()),
      ),
    );
  }
}
