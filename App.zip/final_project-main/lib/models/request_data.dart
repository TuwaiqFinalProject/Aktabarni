class Data {
  static String? text;
  static String? typOfQuestions;
  static int? numberOfQuestions;
}
