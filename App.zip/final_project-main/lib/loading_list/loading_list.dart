List loadingTextList = [
  'All our dreams can come true, if we have the courage to pursue them.',
  'Failure is the opportunity to begin again more intelligently',
  'There is no substitute for hard work'
      'It’s not about perfect. It’s about effort',
  'Do something now; your future self will thank you for later',
  'The best way to gain self-confidence is to do what you are afraid to do',
  'The best time to plant a tree was 20 years ago. The second best time is now.',
  'The secret of getting ahead is getting started.',
];
