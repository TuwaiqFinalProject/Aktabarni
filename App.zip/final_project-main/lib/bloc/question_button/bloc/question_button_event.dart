part of 'question_button_bloc.dart';

abstract class QuestionButtonEvent {}

class NextButtonEvent extends QuestionButtonEvent {}

class BackButtonEvent extends QuestionButtonEvent {}
