part of 'question_button_bloc.dart';

@immutable
sealed class QuestionButtonState {
  final int index;

  const QuestionButtonState(this.index);
}

final class QuestionButtonInitial extends QuestionButtonState {
  const QuestionButtonInitial(super.index);
}

final class GetQuestionButtonState extends QuestionButtonState {
  const GetQuestionButtonState(super.index);
}
