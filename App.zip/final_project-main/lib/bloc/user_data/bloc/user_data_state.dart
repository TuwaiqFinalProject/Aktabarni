part of 'user_data_bloc.dart';

@immutable
sealed class UserDataState {}

final class UserDataInitial extends UserDataState {}

final class GetUserDataState extends UserDataState {
  final String userName;
  final String userEmail;

  GetUserDataState({required this.userName, required this.userEmail});
}

final class FailedUserDataState extends UserDataState {}

final class LoadingUserDataState extends UserDataState {}

// ignore: must_be_immutable
final class GetOwnerUserNameState extends UserDataState {
  String name;

  GetOwnerUserNameState({required this.name});
}
