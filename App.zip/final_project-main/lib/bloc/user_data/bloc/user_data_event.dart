part of 'user_data_bloc.dart';

@immutable
sealed class UserDataEvent {}

final class GetUserDataEvent extends UserDataEvent {}

// ignore: must_be_immutable
final class GetOwnerUserNameEvent extends UserDataEvent {
  String id;

  GetOwnerUserNameEvent({required this.id});
}
