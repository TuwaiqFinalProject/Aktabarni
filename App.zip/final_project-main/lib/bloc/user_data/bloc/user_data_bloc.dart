import 'package:bloc/bloc.dart';
import 'package:final_project/services/database/exams_queries.dart';
import 'package:final_project/services/database/user_data.dart';
import 'package:meta/meta.dart';

part 'user_data_event.dart';
part 'user_data_state.dart';

class UserDataBloc extends Bloc<UserDataEvent, UserDataState> {
  UserDataBloc() : super(UserDataInitial()) {
    on<GetUserDataEvent>((event, emit) async {
      String userName = '';
      String userEmail = '';
      emit(LoadingUserDataState());

      try {
        userName = await SupabaseData().getCurrentUserName();
        userEmail = await SupabaseData.currentUserEmail!;
        emit(GetUserDataState(userName: userName, userEmail: userEmail));
      } catch (e) {
        emit(FailedUserDataState());
      }
    });
    on<GetOwnerUserNameEvent>((event, emit) async {
      emit(LoadingUserDataState());

      try {
        String name;
        name =
            await SupabaseService().getUserOwnerNameById(userOwnerId: event.id);
        emit(GetOwnerUserNameState(name: name));
      } catch (e) {
        emit(FailedUserDataState());
      }
    });
  }
}
